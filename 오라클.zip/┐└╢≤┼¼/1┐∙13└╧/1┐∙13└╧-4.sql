create or replace procedure myproc2
(
  v_cursor out sys_refcursor
)
is
begin
  open v_cursor for
  select * from tblproc order by num desc;
  --close v_cursor; Ŀ���ݳ�
end;


