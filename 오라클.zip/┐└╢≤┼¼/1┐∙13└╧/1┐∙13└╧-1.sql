
create SEQUENCE myseq;

create table tblproc(
    num number(10) PRIMARY key,
    message VARCHAR2(100));
    
create or REPLACE PROCEDURE myproc
(vmessage tblproc.message%type)
is
begin
    insert into tblproc(num, message)
    VALUES(myseq.nextval, vmessage);
    end;
/