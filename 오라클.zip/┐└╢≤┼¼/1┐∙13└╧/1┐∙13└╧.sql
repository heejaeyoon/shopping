set serveroutput on;
DECLARE
v_dept_row dept%rowtype;
cursor c1 is
    select deptno, dname , loc
    from dept;
begin
    open c1;
    loop
    fetch c1 into v_dept_row;
    exit when c1%notfound;
    dbms_output.put_line(v_dept_row.deptno||v_dept_row.dname);
    end loop;
    close c1;
end;

