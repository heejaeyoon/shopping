create table dept_tcl
as select * from dept;

insert into dept_tcl values(50, 'DATABASE', 'SEOUL');

update dept_tcl set loc='PUSAN' where deptno = 40;

delete from dept_tcl where dname = 'RESEARCH';

select*from dept_tcl;

delete from dept_tcl where deptno=50;

update dept_tcl
    set loc='SEOUL'
    where deptno = '30';
    
commit;

update dept_tcl
    set dname='DATABASE'
    where deptno = 30;
