select *
    from emp
    where sal > (select sal from emp where ename = 'JONES');
    
    
select * 
    from emp
    where hiredate < (select hiredate from emp where ename = 'JONES');
    
    
select e.empno, e.ename, e.job, e.sal, d.dname
    from emp e, dept d
    where e.deptno = d.deptno and e.sal > (select avg(sal) from emp);
    
    
select * from emp
    where sal in(select sal from emp where deptno = 30);
    

select * from emp
    where sal < any(select sal from emp where deptno = 30);
    
  
select * from emp
    where exists (select dname from dept where deptno = 10);
    
select * from emp
    where (deptno, sal) in (select deptno, max(sal) from emp group by deptno);
    
select * from (select * from emp where deptno = 10)
