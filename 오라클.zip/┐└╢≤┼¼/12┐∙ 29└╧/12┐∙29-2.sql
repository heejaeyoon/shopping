select * from emp e1
    where sal > (select min(sal)
                from emp e2
                where e2.deptno = e1.deptno)
    order by deptno, sal;
    
select empno, ename, job, sal,
    (select grade from salgrade where e.sal between losal and hisal) as salgrade, 
     deptno,
    (select dname from dept where e.deptno = dept.deptno) as dname
    from emp e;
    
    
select avg(sal) from emp
    where deptno = 10;


select * from emp
    where deptno = 10
    