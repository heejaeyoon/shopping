create table table_pk(
    login_id varchar2(20) primary key,
    login_pwd varchar2(20) not null,
    tel varchar2(20)
    );
    
    select owner, constraint_name, constraint_type, table_name
    from user_constraints
    where table_name like 'table_pk%';
    
    select index_name, table_owner, table_name
    from user_indexes
    where table_name like 'table_pk%';
    
    create table table_pk2(
    login_id varchar2(20)
    constraint tblpk2_lgnid_pk primary key,
    login_pwd varchar2(20)
    constraint tblpk2_lgnpw_nn not null,
    tel varchar2(20)
    );
    
    insert into table_pk(login_id, login_pwd, tel)
    values('test_id_01', 'pwd01', '010-1234-5678');
    
    select owner, constraint_name, constraint_type,
    table_name, r_owner, r_constraint_name
    from user_constraints
    where table_name in ('EMP','DEPT');
    
    insert into EMP(EMPNO, ENAME, JOB ,MGR, HIREDATE, SAL, COMM, DEPTNO)
    VALUES(9999, 'ȫ�浿','CLERK','7788',TO_DATE('2017/04/30', 'YYYY/MM/DD'),
    1200,NULL,50);
    
    create table DEPT_FK(
    DEPTNO NUMBER(2)
    CONSTRAINT DEPTFK_DEPTNO_PK PRIMARY KEY,
    DNAME VARCHAR2(14),
    LOC VARCHAR2(20)
    );
    
    
    CREATE TABLE EMP_FK(
        EMPNO NUMBER(4)
            CONSTRAINT EMPFK_EMPNO_PK PRIMARY KEY,
        ENAME VARCHAR2(10),
        JOB VARCHAR2(9),
        MGR NUMBER(4),
        HIREDATE DATE,
        SAL NUMBER(7,2),
        COMM NUMBER(7,2),
        DEPTNO NUMBER(2)
            CONSTRAINT EMPFK_DEPTNO_FK
                REFERENCES DEPT_FK(DEPTNO)
    );
    
    insert into EMP_FK
    VALUES(9999, 'TEST_NMANE', 'TEST_JOB' , NULL,
        TO_DATE('2001/01/01', 'YYYY/MM/DD'),
        3000,NULL,10);
        
    insert into dept_FK
    VALUES(10, 'TEST_NAME','TEST_LOC');
    
    DELETE FROM DEPT_FK
    WHERE DEPTNO = 10;
    
DROP TABLE EMP_FK;
        