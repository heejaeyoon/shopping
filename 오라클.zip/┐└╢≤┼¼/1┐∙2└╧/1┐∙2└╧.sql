create table dept_temp
as select * from dept;

drop table dept_temp;

insert into dept_temp (deptno,dname,loc)
values (50, 'DATABASE', 'SEOUL');

select * from dept_temp;

commit;

insert into dept_temp (deptno,dname,loc)
values (50, 'DATABASE', 'SEOUL');
insert into dept_temp (deptno,dname,loc)
values (50, 'DATABASE', 'SEOUL');
insert into dept_temp (deptno,dname,loc)
values (50, 'DATABASE', 'SEOUL');

rollback;

insert into dept_temp
values (50, 'DATABASE', 'SEOUL');



create table emp_temp
as select * from emp where 1 <> 1;

insert into emp_temp (empno, ename, job, hiredate, sal , comm, deptno)
values (7777, 'ȫ2', '�λ���', to_date('2023/01/02','YYYY-MM-DD'),4500,1000, 10);

insert into emp_temp (empno, ename, job, hiredate, sal , comm, deptno)
values (5555, 'ȫ3', '����', sysdate, 4500, 1000, 10);

insert into emp_temp (empno, ename, job,mgr, hiredate, sal ,comm, deptno)
select empno, ename, job ,mgr, hiredate, sal,comm,deptno
    from emp
    where deptno = 10;
