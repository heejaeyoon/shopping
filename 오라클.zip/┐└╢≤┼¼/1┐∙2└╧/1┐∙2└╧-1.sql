update dept_temp
    set loc = '����';
    
    
update dept_temp
    set (dname, loc) = (select dname, loc
                        from dept where deptno = 40)
where deptno =40;

delete from dept_temp;

drop table dept_temp;

create table dept_temp
as select * from dept;

drop table emp_temp;

create table emp_temp
as select * from emp;