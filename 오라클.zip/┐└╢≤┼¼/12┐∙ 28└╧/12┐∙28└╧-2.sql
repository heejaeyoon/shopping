select e.ename, e.sal, d.deptno, d.dname, d.loc
    from emp e, dept d
where e.deptno = d.deptno
    and e.ename like 'JO%';
    
select * 
    from emp e, salgrade s
where e.sal between s.losal and s.hisal
    order by ename;