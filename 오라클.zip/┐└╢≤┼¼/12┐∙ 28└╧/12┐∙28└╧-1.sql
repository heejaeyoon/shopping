select * 
    from emp, dept;
    
select e.ename, e.sal, d.deptno, d.dname, d.loc
    from emp e, dept d
    where e.deptno = d.deptno;
    