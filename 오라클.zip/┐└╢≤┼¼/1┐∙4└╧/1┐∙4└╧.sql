create table emp_ddl (
    empno number(4),
    ename varchar2(10),
    job varchar2(9),
    mgr number(4),
    hiredate date,
    sal number(7,2),
    comm number(7,2),
    deptno number(2)
);

select * 
    from emp;
    
create table dept_ddl
as select * from dept;

create table empdept_ddl
    as select e.empno, e.ename, e.job, e.mgr, e.hiredate,
        e.sal, e.comm, e.deptno, d.dname, d.loc
        from emp e, dept d
        where 1<>1;
 
 create table emp_alter
    as select * from emp;
        
alter table emp_alter
  rename column hp to tel;
  
alter table emp_alter
    drop column tel;
    
    
