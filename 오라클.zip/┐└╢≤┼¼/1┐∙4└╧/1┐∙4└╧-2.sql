rename emp_alter to emp_rename;

truncate table emp_rename;

drop table emp_rename;