create sequence member_seq   
increment by 1
start with 1
minvalue 1
maxvalue 10000
nocache;

drop table member;
create table member(
	no number primary key,
	userId varchar2(20) not null,
	userPw varchar2(20),
	userName varchar2(30) not null,
	userEmail varchar2(30),
	userPhone varchar2(20),
	userPostcode varchar2(20),
	userAdd varchar2(200),
	userDetailAdd varchar2(200),
	userGender varchar2(10),
	userBirth varchar2(20),
	userJoindate varchar2(20) default sysdate,	
	userPoint number			
);
select sysdate from dual;
insert into member values(member_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?);

insert into member values(member_seq.nextval,'admin','admin','a','dbsgmlwo45@naver.com','010-1111-1111','����','��','55',22,33,sysdate,9999);


CREATE TABLE Product
(
	product_serial number NOT NULL,
	product_name nvarchar2(50) NOT NULL,
	product_price number NOT NULL,
	product_picture_url nvarchar2(1000) NOT NULL,
	product_description nvarchar2(1000) NOT NULL,
	product_link_url nvarchar2(1000) NOT NULL,
	PRIMARY KEY (product_serial)
);

CREATE SEQUENCE seq_product
increment by 1
start with 1
minvalue 1
maxvalue 10000
nocache;


INSERT INTO product VALUES (seq_product.nextval, '������ Z ����2 5G', 2398000, 'https://images.samsung.com/is/image/samsung/sec-galaxy-z-fold2-f916-sm-f916nznakoo-openbackmysticbronze-308345462?$PD_GALLERY_L_PNG$', '?????','../product/phone1.jsp');
INSERT INTO product VALUES (seq_product.nextval, '������ Z ����2 5G', 2398000, 'https://images.samsung.com/is/image/samsung/sec-galaxy-z-fold2-f916-sm-f916nzkakoo-openbackmysticblack-308345316?$PD_GALLERY_L_PNG$', '?????', '../product/phone1-1.jsp');
INSERT INTO product VALUES (seq_product.nextval, '������ Z �ø� 5G', 1650000, 'https://images.samsung.com/is/image/samsung/sec-galaxy-z-flip-5g-f707-sm-f707nzwakoo-fronttabletopmysticwhite-308345440?$PD_GALLERY_L_PNG$', '?????', '../product/phone2-1.jsp');
INSERT INTO product VALUES (seq_product.nextval, '������ Z ?��? 5G', 1650000, 'https://images.samsung.com/is/image/samsung/sec-galaxy-z-flip-5g-f707-sm-f707nznakoo-frontmysticbronze-308345243?$PD_GALLERY_L_PNG$', '?????', '../product/phone2.jsp');
INSERT INTO product VALUES (seq_product.nextval, '������ Z ?��? 5G', 1650000, 'https://images.samsung.com/is/image/samsung/sec-galaxy-z-flip-5g-f707-sm-f707nzaakoo-frontmysticgray-308345429?$PD_GALLERY_L_PNG$', '?????', '../product/phone2-2.jsp');

INSERT INTO product VALUES (seq_product.nextval, 'iPhone 12 Pro Max', 1490000, 'https://thumbnail8.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/94817515946998-8ce28413-b149-4fb8-bb4e-fdf20f16c2f3.jpg', '?????', '../product/phone3.jsp');
INSERT INTO product VALUES (seq_product.nextval, 'iPhone 12 Pro Max', 1490000, 'https://thumbnail6.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/94834543235119-03a7be31-1f28-434b-ad34-c2877d0b9e8a.jpg', '?????', '../product/phone3-1.jsp');
INSERT INTO product VALUES (seq_product.nextval, 'iPhone 12 Pro Max', 1490000, 'https://thumbnail6.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/94908525995005-be8906b2-964f-430c-b722-c8e9e7c54223.jpg', '?????', '../product/phone3-2.jsp');
INSERT INTO product VALUES (seq_product.nextval, 'iPhone 12', 1480000, 'https://thumbnail6.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/96908678869683-bfb65e17-5459-4178-be9f-c38a42a58c8a.jpg', '?????', '../product/phone4.jsp');
INSERT INTO product VALUES (seq_product.nextval, 'iPhone 12', 1480000, 'https://thumbnail6.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/96545156190109-6542154d-b1c1-47ac-a538-68bb2867023e.jpg', '?????', '../product/phone4-1.jsp');

INSERT INTO product VALUES (seq_product.nextval, 'iPhone 11', 1060000, 'https://thumbnail8.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/2019/10/15/10/4/0bc40b31-ac0d-4495-9901-a3e5a26f39eb.jpg', '?????', '../product/phone5.jsp');
INSERT INTO product VALUES (seq_product.nextval, 'iPhone 11', 1060000, 'https://thumbnail9.coupangcdn.com/thumbnails/remote/230x230ex/image/retail/images/2019/10/15/10/0/c50fc2c3-5e54-4965-a4ff-9591c9a8047d.jpg', '?????', '../product/phone5-1.jsp');


create table product2(
	no number NOT NULL,
	pcode VARCHAR2(20) NOT null,
	pname varchar2(50) NOT NULL,
    petc VARCHAR2(100),
    pdates VARCHAR2(100),
    pimg VARCHAR2(300),
	PRIMARY KEY (no)
    );
    
create table product(
    productno number primary key,
    productName varchar2(50)   not null,
    publeYear Date not null,
    publisher varchar2(70) not null,
    cateCode varchar2(30),
    productPrice number not null,
    productStock number not null,
    productDiscount number(2,2),
    productIntro clob,
    productContents clob,
    regDate date default sysdate,
    updateDate date default sysdate
);    
    
-- Oracle
-- ī�װ��� ���̺�
create table product_bcate(
    tier number(1) not null,
    cateName varchar2(30) not null,
    cateCode varchar2(30) not null,
    cateParent varchar2(30) ,
    primary key(cateCode),
    foreign key(cateParent) references product_bcate(cateCode) 
);
    
CREATE SEQUENCE product_seq
increment by 1
start with 1
minvalue 1
maxvalue 10000
nocache;

CREATE SEQUENCE product_bcate_seq
increment by 1
start with 1
minvalue 1
maxvalue 10000
nocache;


insert into product_bcate(tier, cateName, cateCode) values (1, '����', '100000');
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '�Ҽ�', '101000','100000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ѱ��Ҽ�', '101001','101000');
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '���̼Ҽ�', '101002','101000');
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�Ϻ��Ҽ�', '101003','101000');
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '��/������', '102000','100000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ѱ���', '102001','102000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ؿܽ�', '102002','102000');    
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '����/�濵', '103000','100000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�濵�Ϲ�', '103001','103000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�濵�̷�', '103002','103000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�����Ϲ�', '103003','103000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�����̷�', '103004','103000');    
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '�ڱ���', '104000','100000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '����/ó��', '104001','104000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ڱ�ɷ°��', '104002','104000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ΰ�����', '104003','104000');    
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '�ι�', '105000','100000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ɸ���', '105001','105000');    
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '������', '105002','105000');    
        insert into vam_bcate(tier, cateName, cateCode, cateParent) values (3, 'ö��', '105003','105000');    
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '����/��ȭ', '106000','100000');
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�����Ϲ�', '106001','106000');
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�����', '106002','106000');
        insert into product_bcate(tier, cateName, cateCode, cateParent) values (3, '�ѱ���', '106003','106000');
    insert into product_bcate(tier, cateName, cateCode, cateParent) values (2, '����', '107000','100000');
       